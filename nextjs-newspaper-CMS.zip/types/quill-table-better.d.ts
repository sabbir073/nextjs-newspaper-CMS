// src/types/quill-table-better.d.ts
declare module "quill-table-better" {
    const QuillTableBetter: never;
    export default QuillTableBetter;
}
  