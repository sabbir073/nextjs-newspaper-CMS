-- DropIndex
DROP INDEX "Category_title_key";
