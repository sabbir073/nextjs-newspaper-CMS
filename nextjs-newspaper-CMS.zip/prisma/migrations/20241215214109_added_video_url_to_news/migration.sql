-- AlterTable
ALTER TABLE "News" ADD COLUMN     "video_url" TEXT;
